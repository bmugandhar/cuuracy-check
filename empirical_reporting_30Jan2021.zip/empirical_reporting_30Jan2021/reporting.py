from __future__ import unicode_literals

import os

zone = os.environ.get("ZONE", "dev")
if zone != "dev":
    # Fix for gevent SSL issue...
    import gevent.monkey

    gevent.monkey.patch_all()
else:
    from werkzeug import run_simple

import multiprocessing
from lib import app, Config

if zone != "dev":
    import gunicorn.app.base
    from gunicorn.six import iteritems


    def number_of_workers():
        workers = os.getenv("G_WORKERS", (multiprocessing.cpu_count() * 2) - 1)
        return workers

    def get_timeout():
        timeout = int(os.getenv("G_TIMEOUT", 60))
        return timeout

    class GunicornServer(gunicorn.app.base.BaseApplication):
        def __init__(self, app, options=None):
            self.options = options or {}
            self.application = app
            super(GunicornServer, self).__init__()

        def load_config(self):
            config = dict([(key, value) for key, value in iteritems(self.options)
                           if key in self.cfg.settings and value is not None])
            for key, value in iteritems(config):
                self.cfg.set(key.lower(), value)

        def load(self):
            return self.application

if __name__ == '__main__':
    port = int(os.getenv("EMPIRICAL_REPORTING_PORT", 9052))
    host = os.getenv("SVC_HOST", '0.0.0.0')
    if zone == "dev":
        run_simple(host, port, app,
                   use_reloader=Config.DEBUG, use_debugger=Config.DEBUG, use_evalex=Config.DEBUG)
    else:
        options = {
            'bind': '%s:%s' % (host, port),
            'workers': number_of_workers(),
            'timeout': get_timeout(),
            'worker_class': 'gevent',
            'accesslog':'-'
        }
        GunicornServer(app, options).run()
    print('Starting server at {}:{}'.format(host, port), flush=True)
