import requests
from lib.config import ApiEndPointsConfig
from lib.exception import BadRequestError

def get_rows_per_transaction(project_id_from_request, automation_id_from_request, transaction_id_from_sql_query):

    api = ApiEndPointsConfig
    get_rows_per_transaction_url = api.GET_ROWS_PER_TRANSACTION_ENDPOINT.format(project_id_from_request=project_id_from_request,
                                                                                automation_id_from_request=automation_id_from_request,
                                                                                transaction_id_from_sql_query=transaction_id_from_sql_query)
    with open('authToken.txt') as f:
        auth_token = f.read()
    headers = {'Authorization': 'Bearer ' + auth_token}
    response = requests.get(get_rows_per_transaction_url, headers=headers)
    if response.status_code == 200:
        data = response.json()
        print(data)
        try:
            rows = None
            rows = len(data['results'])
        except Exception as err:
            print(err)
        return rows

    else:
        user_message = "Error while consuming Web services End Point {}. Get request failed with return code = {}.".format(get_rows_per_transaction_url,response.status_code)
        raise BadRequestError(code="REPPORTING_BAD_REQUEST_ERR", user_message=user_message)

