import uuid

from ..exception import ResponseCodes


class ReportingException(Exception):

    def __init__(self, code, original_exception=None, logging_message=None, user_message=None):
        response = ResponseCodes.get(code, None)
        # TODO remove when confident about all response codes being considered
        response = response if response else ResponseCodes.get("REPORTING_UNK_ERR", None)
        if response:
            self.code = code
            # TODO: Encrypt incident id
            self.incident_id = code + "&" + str(uuid.uuid4())
            if original_exception is not None:
                self._original_exception = original_exception
                if hasattr(original_exception, 'incident_id'):
                    self.incident_id = original_exception.incident_id
            self._message = response.get("Logging_Message") + logging_message if logging_message else \
                response.get("Logging_Message")
            self.user_message = response.get("User_Message") + user_message if user_message else \
                response.get("User_Message")
        else:
            raise TypeError("Invalid Exception Code :{}".format(code))

    def __str__(self):
        return "{}".format(self._message)


class SQLError(ReportingException):
    """
        Exception class for SQL Database Error
    """

    def __init__(self, code, original_exception=None, logging_message=None, user_message=None):
        super(SQLError, self).__init__(code, original_exception, logging_message, user_message)


class MongoError(ReportingException):
    """
        Exception class for Mongo Database Error
    """

    def __init__(self, code, original_exception=None, logging_message=None, user_message=None):
        super(MongoError, self).__init__(code, original_exception, logging_message, user_message)


class FileError(ReportingException):
    """
        Exception class for File Error
    """

    def __init__(self, code, original_exception=None, logging_message=None, user_message=None):
        super(FileError, self).__init__(code, original_exception, logging_message, user_message)


class EmpiricalApiError(ReportingException):
    """
        Exception class for Empirical Api Error
    """

    def __init__(self, code, original_exception=None, logging_message=None, user_message=None):
        super(EmpiricalApiError, self).__init__(code, original_exception, logging_message, user_message)


class EmpiricalKeyError(ReportingException):
    """
        Exception class for Empirical Key Error
    """

    def __init__(self, code, original_exception=None, logging_message=None, user_message=None):
        super(EmpiricalKeyError, self).__init__(code, original_exception, logging_message, user_message)


class BadRequestError(ReportingException):
    """
        Exception class for Bad Request Error
    """

    def __init__(self, code, original_exception=None, logging_message=None, user_message=None):
        super(BadRequestError, self).__init__(code, original_exception, logging_message, user_message)


class ResourceNotFoundError(ReportingException):
    """
        Exception class for Resource Not Found Error
    """

    def __init__(self, code, original_exception=None, logging_message=None, user_message=None):
        super(ResourceNotFoundError, self).__init__(code, original_exception, logging_message, user_message)
