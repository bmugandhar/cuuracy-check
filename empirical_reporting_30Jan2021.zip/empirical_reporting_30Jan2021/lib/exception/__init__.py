import json

with open('resources/reporting_codes.json', 'r') as ResponseCode:
    ResponseCodes = json.load(ResponseCode)

from .reporting_exception import ReportingException, SQLError, MongoError, FileError, EmpiricalApiError, \
    EmpiricalKeyError, BadRequestError, ResourceNotFoundError
