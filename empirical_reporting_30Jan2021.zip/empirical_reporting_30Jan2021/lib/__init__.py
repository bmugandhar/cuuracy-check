import sys
import traceback
from flask import Flask

from lib.config import Config
from lib.exception import ResponseCodes, ReportingException

app = Flask(__name__)

from lib import routes, helper

from lib.utils.utils import ConfigUtils, Logger

app.config.from_object(Config)

# Checks if all the config variables have been properly initialised
try:
    config_classes = ConfigUtils.get_class_names_from_module("lib.config")
    for config_class in config_classes:
        obj = ConfigUtils.get_class_instance(config_class)
        variables_dict = obj.__dict__
        for key, value in variables_dict.items():
            if not key.startswith("__") and value is None:
                raise ReportingException(code="CONF_VAR_MISSING_ERR",
                                        logging_message=key + ' value is set to None in "config.py".')
except ReportingException as ee:
    Logger.log_error(ee, traceback.format_exc())
    sys.exit()
except Exception as e:
    exception = ReportingException(code="REPORTING_UNK_ERR", original_exception=e)
    Logger.log_error(exception, traceback.format_exc())
    sys.exit()

