import os
from pytz import timezone


class Config(object):
    """Parent configuration class."""
    DATE_FORMAT = os.environ.get("REPORTING_DATE_FORMAT", "%m/%d/%Y %H:%M:%S")
    USER_READABLE_DATE_FORMAT = os.environ.get("REPORTING_USER_READABLE_DATE_FORMAT", "MM/DD/YYYY HH:MM:SS")
    DEBUG = os.environ.get("EMPIRICAL_APP_DEBUG", True)
    TESTING = os.environ.get("EMPIRICAL_APP_TESTING", False)
    CSRF_ENABLED = True

    HTTP_CODES_WITH_INCIDENT_ID = [500]
    ENCRYPTION_DECRYPTION_KEY = os.getenv("EMPIRICAL_ENCRYPTION_DECRYPTION_KEY", None)


class SQLConfig(object):
    """SQL DB configuration class."""
    SQL_DATABASE = os.environ.get("EMPIRICAL_SQL_DATABASE_NAME", None)
    SQL_SCHEMA = os.environ.get("EMPIRICAL_SQL_SCHEMA_NAME", None)
    SQL_TABLE_PREFIX = os.environ.get("EMPIRICAL_SQL_TABLE_PREFIX", "")
    SQL_USERNAME = os.environ.get("EMPIRICAL_SQL_DATABASE_USERNAME", None)
    SQL_SERVER = os.environ.get("EMPIRICAL_SQL_DATABASE_SERVER", None)
    SQL_PASSWORD = os.environ.get("EMPIRICAL_SQL_DATABASE_PASSWORD", None)


class MongoConfig(object):
    """Mongo DB configuration class."""
    MONGO_PORT = os.environ.get("EMPIRICAL_MONGO_PORT", "27017")
    MONGO_HOST = os.environ.get("EMPIRICAL_MONGO_HOST", None)
    MONGO_USERNAME = os.environ.get("EMPIRICAL_MONGO_USERNAME", None)
    MONGO_PASSWORD = os.environ.get("EMPIRICAL_MONGO_PASSWORD", None)
    MONGO_DATABASE_PREFIX = os.environ.get("EMPIRICAL_MONGO_DATABASE_PREFIX", "")


class TransactionConsumptionStatusConfig(object):
    ReadyToConsume = "IS1"
    Consumed = "IS2"


class TransactionLifeCycleStatusConfig(object):
    Open = "Open"
    Accepted = "Accepted"
    UnderManualReview = "UnderManualReview"
    Completed = "Completed"
    Failed = "Failed"
    DeletionInProgress = "DeletionInProgress"
    DeletionFailed = "DeletionFailed"
    MarkedForDeletion = "MarkedForDeletion"
    All = ""


class TransactionSplitStatusConfig(object):
    ReadyToSplit = "ReadyToSplit"
    SplitInProgress = "SplitInProgress"
    SplitComplete = "SplitComplete"
    SplitError = "SplitError"


class DocumentLifeCycleStatusConfig(object):
    NewImage = "NewImage"
    OCRInProgress = "OCRInProgress"
    OCRComplete = "OCRComplete"
    BusinessQCInProgress = "BusinessQCInProgress"
    BusinessQCComplete = "BusinessQCComplete"
    ManualQCPicked = "PickedForManualQC"
    ManualQCRequired = "ManualQCRequired"
    ManualQCSkippedImage = "ManualQCSkippedImage"
    ManualQCInProgress = "ManualQCInProgress"
    ManualQCComplete = "ManualQCComplete"
    SplitPollerError = "SplitPollerError"
    OCRPollerError = "OCRPollerError"
    BusinessQCPollerError = "BusinessQCPollerError"
    ManualQCPollerError = "ManualQCPollerError"
    AzureTemplateEngineError = "AzureTemplateEngineError"
    BusinessQCServiceError = "BusinessQCServiceError"
    ManualReviewError = "ManualReviewError"
    DeletionFailed = "DeletionFailed"

    # For access logs only
    DocProcessingCompleted = "Completed"
    DocProcessingFailed = "Failed"


class Timezone:
    IST = timezone('Asia/Kolkata')
    MST = timezone('US/Mountain')
    CST = timezone('US/Central')
    GMT = timezone('GMT')
    UTC = timezone('GMT')


class SwaggerConfig:
    SWAGGER_CONFIG = {
        'headers': [],
        'specs': [
            {
                "endpoint": os.getenv("EMPIRICAL_REPORTING_HOST", 'localhost') + ":" + str(
                    os.getenv("EMPIRICAL_REPORTING_PORT", "9005")),
                "route": "/apidocs/v1",
                "rule_filter": lambda rule: True,
                "model_filter": lambda tag: True,
            }
        ],
        "static_url_path": "/flasgger_static",
        "swagger_ui": True,
        "specs_route": "/swagger/"
    }
    SWAGGER_FILE_PATH = "../resources/swagger.yaml"


#class ApiEndPointsConfig(object):
#    GET_ROWS_PER_TRANSACTION_ENDPOINT='http://apvrp51969:9061/api/projects/{project_id_from_request}/automations/{automation_id_from_request}/transactions/{transaction_id_from_sql_query}'

class ApiEndPointsConfig(object):
    GET_ROWS_PER_TRANSACTION_ENDPOINT='http://apvrs62240:9061/api/projects/{project_id_from_request}/automations/{automation_id_from_request}/transactions/{transaction_id_from_sql_query}'