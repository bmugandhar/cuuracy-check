import flask_excel
from lib.utils.db_utils.mssqldb_utils import SqlDB
from lib.utils.utils import DateUtils
from lib.config import Config, Timezone
from datetime import date as date_class


def get_transaction_data(project_id, automation_id, start_date_time, end_date_time, tzone=Timezone.UTC,
                         transaction_status=None, response_format='tsv'):
    transaction_data = get_transactions_data_from_db(project_id, automation_id, start_date_time, end_date_time, tzone,
                                                     transaction_status)
    if response_format == 'tsv':
        return flask_excel.make_response_from_array(transaction_data, 'tsv')
    else:
        raise ValueError('unsupported response format "{}"'.format(response_format))


def get_transactions_data_from_db(project_id, automation_id, start_date_time, end_date_time, tzone=Timezone.UTC,
                                  transaction_status=None):
    start_date_time = DateUtils.convert_date_to_utc(start_date_time)
    end_date_time = DateUtils.convert_date_to_utc(end_date_time)

    sql = SqlDB()
    query = "select trans.ProjectId, trans.AutomationId, templ.TemplateName, trans.TransactionId, trans.Label, " \
            "trans.UploadStartedAt, trans.LifeCycleStatus, trans.ProcessingCompletedOn, doc_count_tb.no_of_pages, " \
            "doc_count_tb.completed_pages, docs.DocumentId, docs.ImageName, docs.UpdatedBy, docs.UpdatedOn, " \
            "docs.DocProcessingComplete from {0}.{1}Project as proj inner join {0}.{1}Automation as auto " \
            "on proj.ProjectId = auto.ProjectId inner join {0}.{1}Transactions as trans " \
            "on auto.AutomationId = trans.AutomationId inner join {0}.{1}Templates as templ " \
            "on trans.TemplateId = templ.TemplateId inner join {0}.{1}Documents as docs " \
            "on trans.TransactionId = docs.TransactionId inner join ( " \
            "select docs1.TransactionId as t_id, count(docs1.DocumentId) as no_of_pages, " \
            "SUM(CAST(docs1.DocProcessingComplete AS INT)) as completed_pages from  {0}.{1}Documents as docs1 " \
            "inner join {0}.{1}Transactions as trans1 on trans1.TransactionId = docs1.TransactionId " \
            "group by docs1.TransactionId) as doc_count_tb on doc_count_tb.t_id = docs.TransactionId " \
            "where trans.ProjectId = {2} and trans.AutomationId = {3} and trans.UploadStartedAt >= '{4}' " \
            "and trans.UploadStartedAt <= '{5}' {6}" \
            "order by proj.ProjectId, auto.AutomationId, trans.UploadStartedAt, docs.UpdatedOn".format(
                        sql.database, sql.table_prefix, project_id, automation_id,
                        start_date_time.strftime("%Y-%m-%d %H:%M:%S"), end_date_time.strftime("%Y-%m-%d %H:%M:%S"),
                        "and trans.LifeCycleStatus = '{}' ".format(transaction_status) if transaction_status else "")
    sql.query(query)
    result = sql.cursor.fetchall()
    sql.close_connection()
    result = convert_datetime_to_a_string_in_req_tz(result, tzone)
    headers = [['ProjectId', 'AutomationId', 'TemplateName', 'TransactionId', 'TransactionLabel',
                'TransactionUploadStartedAt', 'TransactionStatus', 'TransactionProcessingCompletedOn', 'NoOfPages',
                'CompletedPages', 'DocumentId', 'DocumentLabel', 'DocumentUpdatedBy', 'DocumentUpdatedOn',
                'IsDocumentProcessingComplete']]
    headers.extend(result)
    return headers


def convert_datetime_to_a_string_in_req_tz(data, tzone=Timezone.UTC):
    cleaned_data = list()
    for row in data:
        cleaned_row = list()
        for index in range(len(row)):
            value = row[index]
            if isinstance(row[index], date_class):
                value = DateUtils.get_str_from_date(DateUtils.convert_tz(row[index], tzone), Config.DATE_FORMAT)
            cleaned_row.append(value)
        cleaned_data.append(cleaned_row)
    return cleaned_data
