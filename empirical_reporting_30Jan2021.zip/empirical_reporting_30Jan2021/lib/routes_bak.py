import urllib
import flask_excel
from flask import request, Response
from datetime import datetime, timedelta

from lib import app, helper
from lib.config import Config, Timezone, TransactionLifeCycleStatusConfig
from lib.exception import ReportingException, ResourceNotFoundError, BadRequestError
from lib.utils.utils import RequestUtils, ResponseUtils, DateUtils

flask_excel.init_excel(app)


@app.route("/api/projects/<string:project_id>/automations/<string:automation_id>/reports/transactions/detailed",
           methods=['POST'])
def generate_report_tsv(project_id, automation_id):
    try:
        project_id = int(urllib.parse.unquote(project_id))
        automation_id = int(urllib.parse.unquote(automation_id))

        data = RequestUtils.extract_optional_request_data(request)

        str_tzone = data.get('timeZone', None)
        if str_tzone:
            if hasattr(Timezone, str_tzone):
                tzone = getattr(Timezone, str_tzone)
            else:
                raise BadRequestError(code="REPORTING_BAD_REQUEST_ERR",
                                      user_message="{} not a supported timezone.".format(str_tzone))
        else:
            tzone = Timezone.UTC

        str_end_date_time = data.get('endDateTime', None)
        if str_end_date_time:
            end_date_time = DateUtils.get_date_from_str(str_end_date_time, tzone=tzone, label_specifier='End')
        else:
            end_date_time = DateUtils.get_cur_date_time(tzone)

        str_start_date_time = data.get('startDateTime', None)
        if str_start_date_time:
            start_date_time = DateUtils.get_date_from_str(str_start_date_time, tzone=tzone, label_specifier='Start')
        else:
            start_date_time = end_date_time - timedelta(days=1)

        transaction_status = None
        str_transaction_status = data.get('transactionStatus', None)
        if str_transaction_status:
            if hasattr(TransactionLifeCycleStatusConfig, str_transaction_status):
                transaction_status = getattr(TransactionLifeCycleStatusConfig, str_transaction_status)
            else:
                raise BadRequestError(code="REPORTING_BAD_REQUEST_ERR",
                                      user_message="{} is an invalid status.".format(transaction_status))

        return helper.get_transaction_data(project_id, automation_id, start_date_time, end_date_time, tzone=tzone,
                                           transaction_status=transaction_status), 200
    except ReportingException as re:
        return ResponseUtils.create_response_for_exception(re)
    except Exception as e:
        exception = ReportingException("REPORTING_UNK_ERR", original_exception=e)
        return ResponseUtils.create_response_for_exception(exception)


@app.route("/api/reporting/healthcheck", methods=['GET'])
def health():
    return Response(status=200, mimetype='text/json')
