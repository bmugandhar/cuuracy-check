from lib.utils.db_utils.mssqldb_utils import SqlDB
from lib.utils.db_utils.mongo_utils import MongoDB
from bson import ObjectId
from lib.utils.encryption_utils import EncoderDecoder
from operator import itemgetter


def get_transactions_data_from_db1():
    sql = SqlDB()
    query = "select OriginalMongoDBDocId from Stage_Documents where ProjectId=42 and AutomationId=61"
    sql.query(query)
    result = sql.cursor.fetchone()
    sql.close_connection()
    mongo = MongoDB()
    _result = mongo.find_from_collection("{0}#{1}".format(42, 61), "Results", {"_id": ObjectId(result[0])})
    encoder_decoder = EncoderDecoder()
    if _result:
        data = None
        for temp in _result:
            data = temp
            #print(encoder_decoder.decrypt(data["ocrTemplateResult"]["fields"]))
            ocrtemplateresult_fields = list(eval(encoder_decoder.decrypt(data["ocrTemplateResult"]["fields"])))
            #print(len(ocrtemplateresult_fields))
            #print('*'*25)
            #print(encoder_decoder.decrypt(data["manualQCResult"]["fields"]))
            manualqcresult_fields = list(eval(encoder_decoder.decrypt(data["manualQCResult"]["fields"])))
            #print(len(manualqcresult_fields))
            ocrtemplateresult_fields, manualqcresult_fields = [
                        sorted(list_fields, key=itemgetter('key')) for list_fields in (
                                  ocrtemplateresult_fields, manualqcresult_fields)]
            errors = 0
            total_no_values = 0
            for ocr_result, manual_result in zip(ocrtemplateresult_fields, manualqcresult_fields):
                #print(ocr_result["key"],'*'*10, manual_result['key'])
                if ocr_result['key'] == manual_result['key'] and ocr_result['value'] != manual_result['value']:
                    # print(ocr_result['key'])
                    errors += 1
                total_no_values += 1
            print('Total values: {}, Erros: {}, Accuracy: {}'.format(total_no_values, errors,
                            round((total_no_values-errors)/total_no_values*100)))

        mongo.close_connection()
get_transactions_data_from_db()
