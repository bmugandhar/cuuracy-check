from Crypto.Cipher import AES
from Crypto.Util import Counter

from lib.config import Config


class EncoderDecoder:
    def __init__(self):
        self.key = Config.ENCRYPTION_DECRYPTION_KEY
        self.key_bytes = 32

    def encrypt(self, plaintext):
        assert len(self.key) == self.key_bytes

        ctr = Counter.new(AES.block_size * 8)

        aes = AES.new(self.key.encode("utf8"), AES.MODE_CTR, counter=ctr)
        ciphertext = aes.encrypt(str(plaintext).encode())
        return ciphertext

    def decrypt(self, ciphertext):
        assert len(self.key) == self.key_bytes

        ctr = Counter.new(AES.block_size * 8)

        aes = AES.new(self.key.encode("utf8"), AES.MODE_CTR, counter=ctr)

        plaintext = aes.decrypt(ciphertext)
        plaintext_decoded = plaintext.decode('utf-8')
        return plaintext_decoded
