import pymssql

from lib.config import SQLConfig
from lib.exception import SQLError


class SqlDB:

    @staticmethod
    def get_sql_exception(exception, logging_message=""):
        if isinstance(exception, pymssql.InterfaceError):
            code = "SQL_CXN_ERR"
        elif isinstance(exception, pymssql.ProgrammingError):
            code = "SQL_PRGM_ERR"
            if exception.args[0] == 102:
                code = "SQL_SNTX_ERR"
            elif exception.args[0] == 207:
                code = "SQL_INV_COL_ERR"
            elif exception.args[0] == 208:
                code = "SQL_INV_OBJ_ERR"
            elif exception.args[0] == 2818:
                code = "SQL_UNK_PROC_ERR"
            elif exception.args[0] == 4104:
                code = "SQL_MP_ID_NOT_BOUND_ERR"
        elif isinstance(exception, pymssql.OperationalError):
            code = "SQL_OPERATIONAL_ERR"
            if exception.args[0] == 1213:
                code = "SQL_DEADLOCK_ERR"
            elif exception.args[0] == 8169:
                code = "SQL_STRING_TO_UUID_CONVERSION_ERR"
        elif isinstance(exception, pymssql.IntegrityError):
            code = "SQL_INTEGRITY_ERR"
            if exception.args[0] == 515:
                code = "SQL_NULL_INS_ERR"
            elif exception.args[0] == 547:
                code = "SQL_FRGN_KEY_ERR"
            elif exception.args[0] == 2601:
                code = "SQL_UNQ_IDX_VIO_ERR"
            elif exception.args[0] == 2627:
                code = "SQL_UNQ_KEY_VIO_ERR"
        else:
            code = "SQL_UNK_ERR"
        raise SQLError(code=code, original_exception=exception, logging_message=logging_message)

    def __init__(self):
        sql = SQLConfig
        self.server = sql.SQL_SERVER
        self.database = sql.SQL_DATABASE
        self.uid = sql.SQL_USERNAME
        self.pwd = sql.SQL_PASSWORD
        self.schema = sql.SQL_SCHEMA
        self.table_prefix = sql.SQL_TABLE_PREFIX + "_" if sql.SQL_TABLE_PREFIX != "" else sql.SQL_TABLE_PREFIX
        self.conn = pymssql.connect(self.server, self.uid, self.pwd, self.database)
        self.database = self.database + "." + self.schema
        self.cursor = self.conn.cursor()

    def insert_one_into_table(self, table_name, columns, values):
        """
        :param table_name:
        :param columns:
        :param values:
        :return:
        """
        try:
            table_name = self.table_prefix + table_name
            query = "insert into {} ({}) values ({})".format(self.database + "." + table_name, columns, values)
            self.cursor.execute(query)
            self.conn.commit()
            return
        except Exception as e:
            self.conn.rollback()
            self.close_connection()
            return SqlDB.get_sql_exception(e)

    def select_from_table(self, table_name, cols="*", size=None):
        """
        :param cols:
        :param table_name:
        :param size:
        :return:
        """
        try:
            table_name = self.table_prefix + table_name
            query = "select {} from {}".format(cols, self.database + "." + table_name)
            self.cursor.execute(query)
            if size:
                return self.cursor.fetchmany(size=size)
            return self.cursor.fetchall()
        except Exception as e:
            self.close_connection()
            return SqlDB.get_sql_exception(e)

    def select_on_condition_from_table(self, table_name, condition, cols='*', size=None, table_name_complex=False):
        """
        Select specific columns from table on condition
        :param table_name:
        :param condition:
        :param cols:
        :param size:
        :param table_name_complex: true if prefix will be added in multiple places for table name/clause
        :return:
        """
        try:
            if table_name_complex:
                table_name = table_name.replace("<PREFIX>", self.database + "." + self.table_prefix)
            else:
                table_name = self.database + "." + self.table_prefix + table_name

            query = "select {} from {} where {}".format(cols, table_name, condition)
            self.cursor.execute(query)
            if size:
                return self.cursor.fetchmany(size=size)
            return self.cursor.fetchall()
        except Exception as e:
            self.close_connection()
            return SqlDB.get_sql_exception(e)

    def get_primary_key_column_from_table(self, table_name):
        """
        :param table_name:
        :return:
        """
        try:
            query = """select      COLUMN_NAME from      INFORMATION_SCHEMA.TABLE_CONSTRAINTS ,
            INFORMATION_SCHEMA.KEY_COLUMN_USAGE where      INFORMATION_SCHEMA.TABLE_CONSTRAINTS.CONSTRAINT_TYPE = 
            'PRIMARY KEY' and      INFORMATION_SCHEMA.KEY_COLUMN_USAGE.CONSTRAINT_NAME = 
            INFORMATION_SCHEMA.TABLE_CONSTRAINTS.CONSTRAINT_NAME and      
            INFORMATION_SCHEMA.KEY_COLUMN_USAGE.TABLE_NAME = INFORMATION_SCHEMA.TABLE_CONSTRAINTS.TABLE_NAME and      
            INFORMATION_SCHEMA.TABLE_CONSTRAINTS.TABLE_NAME = '""" + table_name + """' """

            self.cursor.execute(query)
            primary_key = self.cursor.fetchone()
            return primary_key[0]
        except Exception as e:
            self.close_connection()
            return SqlDB.get_sql_exception(e)

    def get_primary_key_value_on_condition_from_table(self, table_name, condition):
        try:
            table_name = self.table_prefix + table_name
            result = self.get_primary_key_column_from_table(table_name)
            query = "select {} from {} where {}".format(result, self.database + "." + table_name, condition)
            self.cursor.execute(query)
            primary_key_value = self.cursor.fetchone()
            if primary_key_value is None:
                raise SQLError(code="SQL_PRI_KEY_NOT_FOUND_ERR")
            return primary_key_value[0]
        except SQLError:
            raise
        except Exception as e:
            self.close_connection()
            return SqlDB.get_sql_exception(e)

    def delete_on_condition_from_table(self, table_name, condition):
        """
        :param table_name:
        :param condition:
        :return:
        """
        try:
            table_name = self.table_prefix + table_name
            query = "delete from {} where {}".format(self.database + "." + table_name, condition)
            self.cursor.execute(query)
            self.conn.commit()
            return
        except Exception as e:
            self.conn.rollback()
            self.close_connection()
            return SqlDB.get_sql_exception(e)

    def update_on_condition_in_table(self, table_name, values, condition, limit=None):
        try:
            table_name = self.table_prefix + table_name
            query = "Update {} Set {} Where {}".format(self.database + "." + table_name, values, condition)
            if limit:
                query = "Update top({}) {} Set {} Where {}".format(limit, self.database + "." + table_name, values,
                                                                   condition)
            self.cursor.execute(query)
            self.conn.commit()
            return
        except Exception as e:
            self.conn.rollback()
            self.close_connection()
            return SqlDB.get_sql_exception(e)

    def check_if_table_exists(self, table_name):
        """
        Check if table exists in sql server
        :param table_name:
        :return:
        """
        try:
            table_name = self.table_prefix + table_name
            user = self.schema
            query = '''
                    IF EXISTS (SELECT * FROM sys.objects 
                    WHERE object_id = OBJECT_ID(N'[{0}].[{1}]') AND type in (N'U'))
                    BEGIN
                    Select count(*) from {0}.{1}
                    END
                    '''.format(user, table_name)
            self.cursor.execute(query)
            try:
                result = self.cursor.fetchall()
                if result and len(result) > 0:
                    return
                else:
                    self.close_connection()
                    raise SQLError(code="SQl_TBL_NOT_FOUND_ERR",
                                   logging_message="{} table not found.".format(table_name))
            except SQLError:
                raise
            except Exception as e:
                self.close_connection()
                raise SQLError(code="SQl_TBL_NOT_FOUND_ERR", original_exception=e,
                               logging_message="{} table not found.".format(table_name))
        except SQLError:
            raise
        except Exception as e:
            self.close_connection()
            return SqlDB.get_sql_exception(e, logging_message="{} table not found.".format(table_name))

    def query(self, query):
        """
        Execute complex sql queries, which do not fit with any other sql util
        :param query:
        :return:
        """
        try:
            self.cursor.execute(query)
            return
        except Exception as e:
            self.conn.rollback()
            self.close_connection()
            return SqlDB.get_sql_exception(e)

    def close_connection(self):
        try:
            self.conn.close()
        except Exception as e:
            return SqlDB.get_sql_exception(e)
