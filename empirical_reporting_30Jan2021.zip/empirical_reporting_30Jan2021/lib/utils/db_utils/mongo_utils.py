import urllib

from pymongo import MongoClient, WriteConcern
from pymongo import errors as pymongo_errors

from lib.config import MongoConfig
from lib.exception import MongoError


class MongoDB:
    _mongoConnectionTimeout = 9000

    @staticmethod
    def get_mongo_exception(exception):
        if isinstance(exception, (pymongo_errors.AutoReconnect, pymongo_errors.ConnectionFailure,
                                  pymongo_errors.NetworkTimeout, pymongo_errors.BulkWriteError)):
            code = "MONGO_CXN_ERR"
        elif isinstance(exception, pymongo_errors.OperationFailure):
            code = "MONGO_FAIL_OPERATION_ERR"
            if isinstance(exception, pymongo_errors.CursorNotFound):
                code = "MONGO_CURSOR_NOT_FOUND_ERR"
            elif isinstance(exception, pymongo_errors.ExecutionTimeout):
                code = "MONGO_EXC_TIMEOUT_ERR"
            elif isinstance(exception, pymongo_errors.DuplicateKeyError):
                code = "MONGO_DUPL_KEY_ERR"
        elif isinstance(exception, pymongo_errors.InvalidOperation):
            code = "MONGO_INV_OPERATION_ERR"
        elif isinstance(exception, pymongo_errors.InvalidName):
            code = "MONGO_INV_NAME_ERR"
        elif isinstance(exception, pymongo_errors.CollectionInvalid):
            code = "MONGO_INV_COLL_ERR"
        elif isinstance(exception, pymongo_errors.InvalidURI):
            code = "MONGO_INV_URI_ERR"
        elif isinstance(exception, pymongo_errors.DocumentTooLarge):
            code = "MONGO_DOC_TOO_LRG_ERR"
        else:
            code = "MONGO_UNK_ERR"
        raise MongoError(code=code, original_exception=exception)

    def __init__(self, w=1, j=True, wtimeout=None):
        mongo = MongoConfig
        self.username = urllib.parse.quote_plus(mongo.MONGO_USERNAME)
        self.password = urllib.parse.quote_plus(mongo.MONGO_PASSWORD)
        self.mongo_host = mongo.MONGO_HOST
        self.mongo_port = mongo.MONGO_PORT
        self.database_prefix = mongo.MONGO_DATABASE_PREFIX + "#" if mongo.MONGO_DATABASE_PREFIX != "" else \
            mongo.MONGO_DATABASE_PREFIX
        if self.username == '' and self.password == '':
            self.client = MongoClient('mongodb://%s:%s' % (self.mongo_host, self.mongo_port))
        else:
            self.client = MongoClient('mongodb://%s:%s@%s:%s' % (self.username, self.password,
                                                                 self.mongo_host, self.mongo_port))
        # By default Journaled Write Concern is used with acknowledgement from primary or standalone instance.
        self.write_concern = WriteConcern(w=w, j=j, wtimeout=wtimeout)

    def insert_many_into_collection(self, database, collection_name, data):
        """
        Insert multiple documents into collection
        :param database:
        :param collection_name:
        :param data:
        :return:
        """
        try:
            database = self.database_prefix + database
            db = self.client[database]
            collection = db[collection_name].with_options(write_concern=self.write_concern)
            collection.insert_many(data)
            return
        except Exception as e:
            self.close_connection()
            return MongoDB.get_mongo_exception(e)

    def insert_one_into_collection(self, database, collection_name, data):
        """
        Insert one document into collection
        :param database:
        :param collection_name:
        :param data:
        :return:
        """
        try:
            database = self.database_prefix + database
            db = self.client[database]
            collection = db[collection_name].with_options(write_concern=self.write_concern)
            _id = collection.insert_one(data).inserted_id
            return _id
        except Exception as e:
            self.close_connection()
            return MongoDB.get_mongo_exception(e)

    def find_all_from_collection(self, database, collection_name):
        """
        Find all documents in collection
        :param database:
        :param collection_name:
        :return:
        """
        try:
            database = self.database_prefix + database
            db = self.client[database]
            collection = db[collection_name]
            return collection.find()
        except Exception as e:
            self.close_connection()
            return MongoDB.get_mongo_exception(e)

    def delete_all_from_collection(self, database, collection_name):
        """
        Delete all documents from a collection
        :param database:
        :param collection_name:
        :return:
        """
        try:
            database = self.database_prefix + database
            db = self.client[database]
            collection = db[collection_name].with_options(write_concern=self.write_concern)
            collection.delete_many({})
            return
        except Exception as e:
            self.close_connection()
            return MongoDB.get_mongo_exception(e)

    def delete_one_from_collection(self, database, collection_name, key, value):
        """
        Delete document from collection which matches condition
        :param database:
        :param collection_name:
        :param key:
        :param value:
        :return:
        """
        try:
            database = self.database_prefix + database
            db = self.client[database]
            collection = db[collection_name].with_options(write_concern=self.write_concern)
            collection.delete_one({key: value})
            return
        except Exception as e:
            self.close_connection()
            return MongoDB.get_mongo_exception(e)

    def update_many_into_collection(self, database, collection_name, data, key, upsert=True):
        """
        Update documents in collection for keys
        :param database:
        :param collection_name:
        :param data:
        :param key:
        :param upsert:
        :return:
        """
        try:
            database = self.database_prefix + database
            db = self.client[database]
            collection = db[collection_name].with_options(write_concern=self.write_concern)
            for element in data:
                keys = dict()
                keys[key] = element[key]
                collection.update_one(keys, {"$set": element}, upsert=upsert)
            return
        except Exception as e:
            self.close_connection()
            return MongoDB.get_mongo_exception(e)

    def update_one_into_collection(self, database, collection_name, data, key, value, upsert=False):
        """
        Update one document in collection for key
        :param database:
        :param collection_name:
        :param data:
        :param key:
        :param value:
        :param upsert:
        :return:
        """
        try:
            database = self.database_prefix + database
            db = self.client[database]
            collection = db[collection_name].with_options(write_concern=self.write_concern)
            collection.update_one({key: value}, {"$set": data}, upsert=upsert)
            return
        except Exception as e:
            self.close_connection()
            return MongoDB.get_mongo_exception(e)

    def get_databases(self):
        """
        Get list of databases
        :return:
        """
        try:
            db = self.client.list_database_names()
            return db
        except Exception as e:
            self.close_connection()
            return MongoDB.get_mongo_exception(e)

    def get_collections(self, database):
        """
        Get list of collections
        :param database:
        :return:
        """
        try:
            database = self.database_prefix + database
            db = self.client[database]
            collections = db.collection_names()
            return collections
        except Exception as e:
            self.close_connection()
            return MongoDB.get_mongo_exception(e)

    def find_from_collection(self, database, collection_name, key_value_dict):
        """
        Find documents in collection for key:value condition
        :param key_value_dict:
        :param database:
        :param collection_name:
        :return:
        """
        try:
            database = self.database_prefix + database
            db = self.client[database]
            collection = db[collection_name]
            return collection.find(key_value_dict)
        except Exception as e:
            self.close_connection()
            return MongoDB.get_mongo_exception(e)

    def close_connection(self):
        try:
            self.client.close()
        except Exception as e:
            return MongoDB.get_mongo_exception(e)
