import base64
import inspect
import json
import logging
import os
import sys
import traceback
import uuid
from datetime import datetime
from logging.handlers import TimedRotatingFileHandler

from flask import Response

from lib import app
from lib.config import Config, Timezone
from lib.exception import SQLError, MongoError, FileError, EmpiricalKeyError, ReportingException, EmpiricalApiError, \
    BadRequestError, ResourceNotFoundError


def get_regular_logger(name, pid=None):
    if pid:
        name = name + '-' + str(pid)
    logger = logging.getLogger('my_logger')
    logger.setLevel(logging.DEBUG)
    formatter = logging.Formatter("[%(asctime)s] %(levelname)s (%(process)-10s) (%(threadName)-10s) - %(message)s")

    handler = TimedRotatingFileHandler(name + '.log', when='W0')
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(formatter)
    if not logger.hasHandlers():
        logger.addHandler(handler)
    gunicorn_error_logger = logging.getLogger('gunicorn.error')
    app.logger.handlers.extend(gunicorn_error_logger.handlers)
    return logger


class Logger:
    pid_regular_logger = dict()

    @staticmethod
    def get_pid_regular_logger():
        if os.getpid() not in Logger.pid_regular_logger.keys():
            if not os.path.exists('logs'):
                os.makedirs('logs')
            Logger.pid_regular_logger[os.getpid()] = get_regular_logger('logs/api', os.getpid())
        return Logger.pid_regular_logger[os.getpid()]

    @staticmethod
    def log_error(exception, traceback):
        """
        Log error
        :param exception:
        :param traceback:
        :return:
        """
        if exception:
            Logger.get_pid_regular_logger().error("\nIncident Id: {0},"
                                                  "\nException Code: {1},"
                                                  "\nError Logging Message: {2}"
                                                  "\nError Traceback: {3}"
                                                  .format(exception.incident_id,
                                                          exception.code,
                                                          exception,
                                                          traceback))

    @staticmethod
    def log_debug(message, traceback):
        Logger.get_pid_regular_logger().logger.debug(message, traceback)

    @staticmethod
    def log_info(message):
        Logger.get_pid_regular_logger().info(message)


class ConfigUtils:
    @staticmethod
    def get_class_instance(class_name):
        parts = class_name.split('.')
        module = ".".join(parts[:-1])
        m = __import__(module)
        for comp in parts[1:]:
            m = getattr(m, comp)
        return m

    @staticmethod
    def get_class_names_from_module(module_name):
        class_list = list()
        for name, obj in inspect.getmembers(sys.modules[module_name]):
            if inspect.isclass(obj):
                class_list.append(str(obj)[8:-2])
        return class_list


class ExceptionResponseUtils:
    _exception_to_http_code_dict = {
        ReportingException.__name__: 500,
        SQLError.__name__: 500,
        MongoError.__name__: 500,
        FileError.__name__: 500,
        EmpiricalApiError.__name__: 500,
        EmpiricalKeyError.__name__: 400,
        BadRequestError.__name__: 400,
        ResourceNotFoundError.__name__: 404
    }

    @staticmethod
    def get_http_response_for_exception(exception):
        """
        create http response for exception cases
        :param exception:
        :return:
        """
        http_status = ExceptionResponseUtils._exception_to_http_code_dict.get(type(exception).__name__, 500)
        response = dict()
        if http_status in Config.HTTP_CODES_WITH_INCIDENT_ID:
            response['incidentId'] = str(base64.b64encode(exception.incident_id.encode("utf-8")), "utf-8")
        response['message'] = exception.user_message
        return response, http_status


class RequestUtils:
    @staticmethod
    def extract_request_data(req):
        try:
            req.get_json()
        except Exception as e:
            raise BadRequestError(code="MISSING_PARAMS_ERR", user_message="JSON body cannot be empty.",
                                  original_exception=e)
        if req.get_json() is None:
            if req.form is None:
                raise EmpiricalKeyError(code="MISSING_PARAMS_ERR")
            data = json.loads(json.dumps(dict(req.form)))
            # As developing on windows, the request works differently. Need to get inner level values.
            for k, v in data.items():
                if isinstance(v, list):
                    data[k] = v[0]
        else:
            data = req.get_json()
        return data

    @staticmethod
    def extract_optional_request_data(req):
        data = {}
        try:
            req.get_json()
            if req.get_json():
                data = req.get_json()
            elif req.form:
                data = json.loads(json.dumps(dict(req.form)))
                # As developing on windows, the request works differently. Need to get inner level values.
                for k, v in data.items():
                    if isinstance(v, list):
                        data[k] = v[0]
        except Exception as e:
            pass
        return data


class ResponseUtils:
    @staticmethod
    def create_response_for_exception(exception):
        Logger.log_error(exception, traceback.format_exc())
        response, http_status = ExceptionResponseUtils.get_http_response_for_exception(exception)
        return Response(json.dumps(response), http_status, mimetype='text/json')


class Utils:
    @staticmethod
    def validate_uuid4(uuid_string):
        """
        Validate that a UUID string is in
        fact a valid uuid4.
        Happily, the uuid module does the actual
        checking for us.
        It is vital that the 'version' kwarg be passed
        to the UUID() call, otherwise any 32-character
        hex string is considered valid.
        :param uuid_string:
        :return:
        """
        try:
            uuid.UUID(uuid_string, version=4)
        except ValueError:
            # If it's a value error, then the string
            # is not a valid hex code for a UUID.
            return False
        return True


class DateUtils:

    @staticmethod
    def get_date_from_str(str_date, date_format=Config.DATE_FORMAT, label_specifier='', tzone=Timezone.UTC):
        if str_date:
            str_date = str_date.strip()
            try:
                return tzone.localize(datetime.strptime(str_date, date_format))
            except ValueError as ve:
                    raise BadRequestError(code="REPORTING_BAD_REQUEST_ERR",
                                          user_message="{}Date time does not conform to the format {}.".
                                          format(label_specifier, Config.USER_READABLE_DATE_FORMAT),
                                          original_exception=ve)

    @staticmethod
    def get_str_from_date(date_obj, date_format=Config.DATE_FORMAT):
        if date_obj:
            try:
                return datetime.strftime(date_obj, date_format)
            except ValueError as ve:
                raise BadRequestError(code="REPORTING_BAD_REQUEST_ERR",
                                      user_message="Invalid Date format: {}".format(date_format),
                                      original_exception=ve)

    @staticmethod
    def get_cur_date_time(tzone=Timezone.UTC):
        return datetime.now(tzone)

    @staticmethod
    def convert_date_to_utc(datetime_obj):
        return DateUtils.convert_tz(datetime_obj, Timezone.UTC)

    @staticmethod
    def convert_tz(date_obj, to_tz):
        if not date_obj.tzname():
            date_obj = Timezone.UTC.localize(date_obj)
        return date_obj.astimezone(to_tz)
