# empirical_reporting
adhoc http reporting module for IBR (move this as a standard reporting module for Empirical)
